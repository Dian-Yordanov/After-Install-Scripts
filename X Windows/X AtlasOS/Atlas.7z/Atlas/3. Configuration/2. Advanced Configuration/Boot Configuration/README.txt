Here you can change the boot configuration for Windows, which can modify system timers, QoL, mitigations and more.

You can either completely mess things up, or potentially (unlikely) improve performance with experimental options.

There might also be undocumented options.