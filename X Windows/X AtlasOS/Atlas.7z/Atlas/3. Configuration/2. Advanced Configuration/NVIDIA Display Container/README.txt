Disabling "NVIDIA Display Container LS"
-----------------------------------------
This allows you to enable/disable the 'NVIDIA Display Container LS service', which connects to a few NVIDIA IPs and uses a tiny bit of CPU usage.
These scripts are aimed at users that have a stripped driver, and people that barely touch the NVIDIA Control Panel.

Warning:
Disabling the "NVIDIA Display Container LS" service will make it so you can not use NVIDIA Control Panel and other NVIDIA driver features!
However, you can enable it again and add a context menu to the desktop for easily enabling/disabling it.