// ==UserScript==
// @name        _Adding a live button2
// @description Adds live example button, with styling.
// @include     https://www.reddit.com/r/all/
// @grant       GM_addStyle
// ==/UserScript==

/*--- Create a button in a container div.  It will be styled and
    positioned with CSS.
*/

// create button
var btn = document.createElement( 'input' );
with( btn ) {
  setAttribute( 'onclick', 'alert( "you clicked me!" )' );
  setAttribute( 'value', 'click me!' );
  setAttribute( 'type', 'button' );
}

// append at end
document.getElementById( "header-bottom-left" ).appendChild( btn );

function ButtonClickAction (zEvent) {
    /*--- For our dummy action, we'll just add a line of text to the top
        of the screen.
    */
    var zNode       = document.createElement ('p');
    zNode.innerHTML = 'The button was clicked.';
    document.getElementById ("myContainer").appendChild (zNode);
}

GM_addStyle(`

// #header-bottom-left { color: white; background-color: black }
// img { border: 0 }
// .footer { width: 875px; }

#header-bottom-left input {
    margin-left: 111px;
}


`);
