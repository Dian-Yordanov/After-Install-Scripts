// ==UserScript==
// @name        Youtube Video Ratings Bar with Power Meter
// @description This used to display ratings bar on YouTube thumbnails, but Google has blocked how it gets its data. I'm disabling it for now in case people still have it running.
// @version     2020.03.24
// @author      lednerg
// @copyright   2014, lednerg (https://openuserjs.org/users/lednerg)
// @updateURL   https://openuserjs.org/meta/lednerg/Youtube_Video_Ratings_Bar_with_Power_Meter.meta.js
// @downloadURL https://openuserjs.org/install/lednerg/Youtube_Video_Ratings_Bar_with_Power_Meter.user.js
// @license     MIT
// @icon        http://i.imgur.com/ZfKR597.png
// @namespace   https://openuserjs.org/users/lednerg
// ==/UserScript==

/* If I can figure out a way to get this script to work within the constraints Google is placing on it, I'll update it. For now, I'm going to keep it from wasting your CPU cycles and bandwidth and simply disable it. */