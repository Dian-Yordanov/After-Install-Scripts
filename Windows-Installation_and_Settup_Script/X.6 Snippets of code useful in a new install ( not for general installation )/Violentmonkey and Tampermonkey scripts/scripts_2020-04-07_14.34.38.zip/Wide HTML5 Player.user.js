// ==UserScript==
// @name         Wide HTML5 Player
// @version      1.0
// @run-at       document-start
// @grant        none
// @match        *://*/*.mp3*
// @match        *://*/*.ogg*
// @match        *://*/*.mp4*
// @match        file:///*
// ==/UserScript==
(function() {
    if (document.body.children.length == 1 && document.body.children[0].tagName == "VIDEO") {
        document.body.children[0].style.width = "80%";
    }
})();