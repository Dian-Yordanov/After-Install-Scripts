// ==UserScript==
// @name         YWOT Paster
// @namespace    https://greasyfork.org/en/users/28185-bit
// @version      1.3
// @description  Your World Of Text text pasting allocator.
// @author       Bit
// @include      http*://www.yourworldoftext.com/*
// @grant        none
// ==/UserScript==

Permissions.can_paste = function() {return true;};