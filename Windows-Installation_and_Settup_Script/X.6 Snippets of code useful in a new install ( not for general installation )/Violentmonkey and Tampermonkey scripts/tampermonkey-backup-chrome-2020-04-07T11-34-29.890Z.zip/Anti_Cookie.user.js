// ==UserScript==
// @name Anti_Cookie
// @description fuck cookie bans.
// @namespace anon.ops
// @include *://*.4chan.org/*
// @author team Anonymous
// @version 1
// ==/UserScript==

(function(){
    // Generate a random 4chan_pass value
    function gen_rnd(){
        var pass, chars, i, len, rnd;

chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
len = chars.length;
pass = '';

        for (var i = 0; i < 32; i++) {
rnd = Math.floor(Math.random() * len);
pass += chars.substring(rnd,rnd + 1);
        }

        return '_' + pass;
    }
    // Continuously assign a new value to the cookie in order to subvert user identification
setInterval(function() {
document.cookie = '4chan_pass='+gen_rnd()+';expires=Thu, 01 May 2016 00:00:01 GMT;';
        }, 1000);
})();